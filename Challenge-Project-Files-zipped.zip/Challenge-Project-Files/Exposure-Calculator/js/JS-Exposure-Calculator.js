// Exposure Calculator

// This calculator allows users to Set the increments for Aperture(F-Stop), 
// Shutter Speed, and ISO. This selection makes visible the cooresponding 
// increment drop-down boxes. In the increment drop-down boxes users can input
// the camera setting that are currently returning a good exposure from their
// camera. From this input a baseline exposure value is calculated. The 'Set Exposure'
// button makes visible a second input row, the 'Adjust' row, with the cooresponding
// increment 'Adjust' drop-down boxes match the 'Settings' row, and passes
// the values of the 'Settings' row drop-down boxes to the 'Adjust' row drop-down
// boxes, and then calcultaes whether the total values of the setting in the
// two rows match. The values always match when passed by the 'Set Exposure' button
// and 'Exposure Match' is displayed in the 'Adjusted Value' box.
// This pushed match reinforces the functionality of the 'Adjust' row form the user.
// At this point, the user can change a value in one or more of the drop-down boxes
// on the 'Adjust' row, and the 'Adjusted Value' box will display the calculated
// difference between the good exposure values set in the top 'Settings' row with the values
// now in the bottom 'Adjust' row. This allows the user to adjust a critical setting, 
// like increasing the Shutter Speed to freeze the motion of someone running, calculates
// the new Exposure Value and displays the new Exposure Value in the 'Adjusted Value'
// indicating how many Stops of light, '+' or '-', the new Exposure Value is from the
// Baseline Value set ing the top 'Settings' row. The user can then experiment with changing
// values of the other settings to achieve an 'Exposure Match'. 
// 
// With the example of adjusting Shutter Speed
// If a good exposure is returned by the settings F/8, 1/125, ISO 200;
// these are the initial settings input in the top 'Settings row.
// When the 'Set Exposure' button refeals the 'Adjsut' row and pushed the
// values from the 'Settings' row, then user can now adjust the Shutter Speed
// to 1/500 to freeze the motion of a person running. The 'Adjusted Value' box will
// now indicate that the new exposure value is '-2 Stops'. By adjusting the value in the
// F-Stop and/or ISO 'Adjust' drop-down boxes, values can be found to once again have
// an 'Exposure Match'. As often is the case, this example has mulitple solutions.
// Using an F-Stop of F/4, an ISO of 800, or an F-Stop of F/5.6 with an ISO of 400 all
// return an 'Exposure Match'.

// Variables for the F-Stop Increment Choose and Increment drop-down boxes 
const fSelector = document.querySelector('#f-stops');
const fFull = document.querySelector('#f-stop-full-setting-container');
const fHalf = document.querySelector('#f-stop-half-setting-container');
const fThird = document.querySelector('#f-stop-third-setting-container');

// Makes the F-Stop Increment drop-down boxes visible cooresponding to the Increment choosen 
fSelector.addEventListener("change", function() {
    if(fSelector.value == "Full-Stops")
    {
        fFull.classList.add('active');
        fHalf.classList.remove('active');
        fThird.classList.remove('active');
    }
    if(fSelector.value == "Half-Stops")
    {
        fFull.classList.remove('active');
        fHalf.classList.add('active');
        fThird.classList.remove('active');
    }
    if(fSelector.value == "Third-Stops")
    {
        fFull.classList.remove('active');
        fHalf.classList.remove('active');
        fThird.classList.add('active');
    }
});

// Variables for the Shutter Speed Increment Choose and Increment drop-down boxes 
const sSelector = document.querySelector('#shutter-speeds');
const sFull = document.querySelector('#shutter-speed-full-setting-container');
const sHalf = document.querySelector('#shutter-speed-half-setting-container');
const sThird = document.querySelector('#shutter-speed-third-setting-container');

// Makes the Shutter Speed Increment drop-down boxes visible cooresponding to the Increment choosen 
sSelector.addEventListener("change", function() {
    if(sSelector.value == "Full-Stops")
    {
        sFull.classList.add('active');
        sHalf.classList.remove('active');
        sThird.classList.remove('active');
    }
    if(sSelector.value == "Half-Stops")
    {
        sFull.classList.remove('active');
        sHalf.classList.add('active');
        sThird.classList.remove('active');
    }
    if(sSelector.value == "Third-Stops")
    {
        sFull.classList.remove('active');
        sHalf.classList.remove('active');
        sThird.classList.add('active');
    }
});
// Variables for the ISO Increment Choose and Increment drop-down boxes 
const iSelector = document.querySelector('#isos');
const iFull = document.querySelector('#iso-full-setting-container');
const iHalf = document.querySelector('#iso-half-setting-container');
const iThird = document.querySelector('#iso-third-setting-container');

// Makes the ISO Increment drop-down boxes visible cooresponding to the Increment choosen 
iSelector.addEventListener("change", function() {
    if(iSelector.value == "Full-Stops")
    {
        iFull.classList.add('active');
        iHalf.classList.remove('active');
        iThird.classList.remove('active');
    }
    if(iSelector.value == "Half-Stops")
    {
        iFull.classList.remove('active');
        iHalf.classList.add('active');
        iThird.classList.remove('active');
    }
    if(iSelector.value == "Third-Stops")
    {
        iFull.classList.remove('active');
        iHalf.classList.remove('active');
        iThird.classList.add('active');
    }
});

// Variable For Exposure Calculation

// 'Settings' row
let currentFStopllEx = 0;
let currentShutterSpeddEx = 0;
let currentISOEx = 0;
let currentTotalEx  = 0;

let baselineValue = document.querySelector('#baseline-value');

// 'Adjust' row
let adjustFStopllEx = 0;
let adjustShutterSpeddEx = 0;
let adjustISOEx = 0;
let adjustTotalEx = 0;

let adjustValue = document.querySelector('#adjust-value');

// Rounding function that rounds 'value' to the decimal point indicated by 'precision'
// This is used in calculating the'Adjust Value' of 'Adjust Full & Thirds' Event Listeners
function round(value, precision) {
    var multiplier = Math.pow(10, precision || 0);
    return Math.round(value * multiplier) / multiplier;
}

// Varialbe for the Shutter Speed 'Full' drop-down box
const fStopFullSelector = document.querySelector('#f-stop-full-settings');

// When the F-Stop Setting 'Full' drop-down box is visible, event listener calculates
//  the 'Baseline Exposure'
fStopFullSelector.addEventListener("change", function() {

    // code to calculate an exposure value from the selected option in the drop-down
    currentFStopllEx = 0;

    for(i = 1; i <= fFullOption.options[fFullOption.selectedIndex].value; i++) {
        
        currentFStopllEx++;
    }

    // Code to calculate the "Baseline Value" value and  set the text
    currentTotalEx = currentFStopllEx + currentShutterSpeddEx + currentISOEx;
    baselineValue.innerText = round(currentTotalEx, 1) + ' Stops';
});

// Varialbe for the F-Stop 'Full & Half' drop-down box
const fStopHalfSelector = document.querySelector('#f-stop-half-settings');

// When the F-Stop Setting 'Full & Half' drop-down box is visible, event listener calculates
//  the 'Baseline Exposure'
fStopHalfSelector.addEventListener("change", function() {

    // code to calculate an exposure value from the selected option in the drop-down
    currentFStopllEx = 0;
        
    for(i = 0; i <= fHalfOption.options[fHalfOption.selectedIndex].value; i++) {
        
        currentFStopllEx = currentFStopllEx + .5;
    }

    // Code to calculate the "Baseline Value" value and  set the text
    currentTotalEx = currentFStopllEx + currentShutterSpeddEx + currentISOEx;
    baselineValue.innerText = round(currentTotalEx, 1) + ' Stops';
});

// Varialbe for the F-Stop 'Full & Thirds' drop-down box
const fStopThirdSelector = document.querySelector('#f-stop-third-settings');

// When the F-Stop Setting 'Full & Thirds' drop-down box is visible, event listener calculates
//  the 'Baseline Exposure'
fStopThirdSelector.addEventListener("change", function() {

    // code to calculate an exposure value from the selected option in the drop-down
    currentFStopllEx = .3333333333333;

    for(i = 0; i <= fThirdOption.options[fThirdOption.selectedIndex].value; i++) {
        
        currentFStopllEx = currentFStopllEx + 1/3;
        // Code to make whole numbers when 'Thirds' are used
        round(currentFStopllEx, 1)
        if(currentFStopllEx > -0.8 && currentFStopllEx < 0.2){
            currentFStopllEx = 0;
        }
        if(currentFStopllEx > 0.8 && currentFStopllEx < 1.2){
            currentFStopllEx = 1;
        }
        if(currentFStopllEx > 1.8 && currentFStopllEx < 2.2){
            currentFStopllEx = 2;
        }
        if(currentFStopllEx > 2.8 && currentFStopllEx < 3.2){
            currentFStopllEx = 3;
        }
        if(currentFStopllEx > 3.8 && currentFStopllEx < 4.2){
            currentFStopllEx = 4;
        }
        if(currentFStopllEx > 4.8 && currentFStopllEx < 5.2){
            currentFStopllEx = 5;
        }
        if(currentFStopllEx > 5.8 && currentFStopllEx < 6.2){
            currentFStopllEx = 6;
        }
        if(currentFStopllEx > 6.8 && currentFStopllEx < 7.2){
            currentFStopllEx = 7;
        }
        if(currentFStopllEx > 7.8 && currentFStopllEx < 8.2){
            currentFStopllEx = 8;
        }
        if(currentFStopllEx > 8.8 && currentFStopllEx < 9.2){
            currentFStopllEx = 9;
        }
        if(currentFStopllEx > 9.8 && currentFStopllEx < 10.2){
            currentFStopllEx = 10;
        }
        if(currentFStopllEx > 10.8 && currentFStopllEx < 11.2){
            currentFStopllEx = 11;
        }
    }

    // Code to calculate the "Baseline Value" value and  set the text
    currentTotalEx = currentFStopllEx + currentShutterSpeddEx + currentISOEx;
    baselineValue.innerText = round(currentTotalEx, 1) + ' Stops';
});

// Varialbe for the Shutter Speed 'Full' drop-down box
const sStopFullSelector = document.querySelector('#shutter-speed-full-settings');

// When the Shutter Speed Setting 'Full' drop-down box is visible, event listener calculates
//  the 'Baseline Exposure'
sStopFullSelector.addEventListener("change", function() {

    // code to calculate an exposure value from the selected option in the drop-down
    currentShutterSpeddEx = 0;

    for(i = 1; i <= sFullOption.options[sFullOption.selectedIndex].value; i++) {
        
        currentShutterSpeddEx++;
     }

    // Code to calculate the "Baseline Value" value and  set the text
    currentTotalEx = currentFStopllEx + currentShutterSpeddEx + currentISOEx;
    baselineValue.innerText = round(currentTotalEx, 1) + ' Stops';
});

// Varialbe for the Shutter Speed 'Full & Half' drop-down box
const sStopHalfSelector = document.querySelector('#shutter-speed-half-settings');

// When the Shutter Speed Setting 'Full & Half' drop-down box is visible, event listener calculates
//  the 'Baseline Exposure'
sStopHalfSelector.addEventListener("change", function() {

    // code to calculate an exposure value from the selected option in the drop-down
    currentShutterSpeddEx = 0;
        
    for(i = 0; i <= sHalfOption.options[sHalfOption.selectedIndex].value; i++) {
        
        currentShutterSpeddEx = currentShutterSpeddEx + .5;
    }

    // Code to calculate the "Baseline Value" value and  set the text
    currentTotalEx = currentFStopllEx + currentShutterSpeddEx + currentISOEx;
    baselineValue.innerText = round(currentTotalEx, 1) + ' Stops';
});

// Varialbe for the Shutter Speed 'Full & Thirds' drop-down box
const sStopThirdSelector = document.querySelector('#shutter-speed-third-settings');

// When the Shutter Speed Setting 'Full & Thirds' drop-down box is visible, event listener calculates
//  the 'Baseline Exposure'
sStopThirdSelector.addEventListener("change", function() {

    // code to calculate an exposure value from the selected option in the drop-down
    currentShutterSpeddEx = .3333333333333;

    for(i = 0; i <= sThirdOption.options[sThirdOption.selectedIndex].value; i++) {

        currentShutterSpeddEx = currentShutterSpeddEx + 1/3;
        // Code to make whole numbers when 'Thirds' are used
        round(currentShutterSpeddEx, 1)
        if(currentShutterSpeddEx > -0.8 && currentShutterSpeddEx < 0.2){
            currentShutterSpeddEx = 0;
        }
        if(currentShutterSpeddEx > 0.8 && currentShutterSpeddEx < 1.2){
            currentShutterSpeddEx = 1;
        }
        if(currentShutterSpeddEx > 1.8 && currentShutterSpeddEx < 2.2){
            currentShutterSpeddEx = 2;
        }
        if(currentShutterSpeddEx > 2.8 && currentShutterSpeddEx < 3.2){
            currentShutterSpeddEx = 3;
        }
        if(currentShutterSpeddEx > 3.8 && currentShutterSpeddEx < 4.2){
            currentShutterSpeddEx = 4;
        }
        if(currentShutterSpeddEx > 4.8 && currentShutterSpeddEx < 5.2){
            currentShutterSpeddEx = 5;
        }
        if(currentShutterSpeddEx > 5.8 && currentShutterSpeddEx < 6.2){
            currentShutterSpeddEx = 6;
        }
        if(currentShutterSpeddEx > 6.8 && currentShutterSpeddEx < 7.2){
            currentShutterSpeddEx = 7;
        }
        if(currentShutterSpeddEx > 7.8 && currentShutterSpeddEx < 8.2){
            currentShutterSpeddEx = 8;
        }
        if(currentShutterSpeddEx > 8.8 && currentShutterSpeddEx < 9.2){
            currentShutterSpeddEx = 9;
        }
        if(currentShutterSpeddEx > 9.8 && currentShutterSpeddEx < 10.2){
            currentShutterSpeddEx = 10;
        }
        if(currentShutterSpeddEx > 10.8 && currentShutterSpeddEx < 11.2){
            currentShutterSpeddEx = 11;
        }
    }

    // Code to calculate the "Baseline Value" value and  set the text
    currentTotalEx = currentFStopllEx + currentShutterSpeddEx + currentISOEx;
    baselineValue.innerText = round(currentTotalEx, 1) + ' Stops';
});

// Varialbe for the ISO 'Full' drop-down box
const iStopFullSelector = document.querySelector('#iso-full-settings');

// When the ISO Setting 'Full' drop-down box is visible, event listener calculates
//  the 'Baseline Exposure'
iStopFullSelector.addEventListener("change", function() {

    // code to calculate an exposure value from the selected option in the drop-down
    currentISOEx = 0;

    for(i = 1; i <= iFullOption.options[iFullOption.selectedIndex].value; i++) {
        
        currentISOEx++;
    }

    // Code to calculate the "Baseline Value" value and  set the text
    currentTotalEx = currentFStopllEx + currentShutterSpeddEx + currentISOEx;
    baselineValue.innerText = round(currentTotalEx, 1) + ' Stops';
});

// Varialbe for the ISO 'Full & Half' drop-down box
const iStopHalfSelector = document.querySelector('#iso-half-settings');

// When the ISO Setting 'Full & Half' drop-down box is visible, event listener calculates
//  the 'Baseline Exposure'
iStopHalfSelector.addEventListener("change", function() {

     // code to calculate an exposure value from the selected option in the drop-down
    currentISOEx = 0;
        
    for(i = 0; i <= iHalfOption.options[iHalfOption.selectedIndex].value; i++) {
        
        currentISOEx = currentISOEx + .5;
    }

    // Code to calculate the "Baseline Value" value and  set the text
    currentTotalEx = currentFStopllEx + currentShutterSpeddEx + currentISOEx;
    baselineValue.innerText = round(currentTotalEx, 1) + ' Stops';
});

// Varialbe for the ISO 'Full & Thirds' drop-down box
const iStopThirdSelector = document.querySelector('#iso-third-settings');

// When the ISO Setting 'Full & Thirds' drop-down box is visible, event listener calculates
//  the 'Baseline Exposure'
iStopThirdSelector.addEventListener("change", function() {

    // code to calculate an exposure value from the selected option in the drop-down
    currentISOEx = .3333333333333;

    for(i = 0; i <= iThirdOption.options[iThirdOption.selectedIndex].value; i++) {
        
        currentISOEx = currentISOEx + 1/3;
        // Code to make whole numbers when 'Thirds' are used
        round(currentISOEx, 1)
        if(currentISOEx > -0.8 && currentISOEx < 0.2){
            currentISOEx = 0;
        }
        if(currentISOEx > 0.8 && currentISOEx < 1.2){
            currentISOEx = 1;
        }
        if(currentISOEx > 1.8 && currentISOEx < 2.2){
            currentISOEx = 2;
        }
        if(currentISOEx > 2.8 && currentISOEx < 3.2){
            currentISOEx = 3;
        }
        if(currentISOEx > 3.8 && currentISOEx < 4.2){
            currentISOEx = 4;
        }
        if(currentISOEx > 4.8 && currentISOEx < 5.2){
            currentISOEx = 5;
        }
        if(currentISOEx > 5.8 && currentISOEx < 6.2){
            currentISOEx = 6;
        }
        if(currentISOEx > 6.8 && currentISOEx < 7.2){
            currentISOEx = 7;
        }
        if(currentISOEx > 7.8 && currentISOEx < 8.2){
            currentISOEx = 8;
        }
        if(currentISOEx > 8.8 && currentISOEx < 9.2){
            currentISOEx = 9;
        }
        if(currentISOEx > 9.8 && currentISOEx < 10.2){
            currentISOEx = 10;
        }
        if(currentISOEx > 10.8 && currentISOEx < 11.2){
            currentISOEx = 11;
        }
    }

// Code to calculate the "Baseline Value" value and  set the text
currentTotalEx = currentFStopllEx + currentShutterSpeddEx + currentISOEx;
baselineValue.innerText = round(currentTotalEx, 1) + ' Stops';
});

// Variable for 'Set Exposure' buttton
const setExposure = document.querySelector('#set-exposure-btn');

// Setting's Increment Selector drop-down boxes and columns

// F-Stop Increment Selector drop-down box and column
const fAdjustContainer =document.querySelector('#adjust-f-stop-column');
const fAdjustFull = document.querySelector('#adjust-f-stop-full-setting-container');
const fAdjustHalf = document.querySelector('#adjust-f-stop-half-setting-container');
const fAdjustThird = document.querySelector('#adjust-f-stop-third-setting-container');

// Shutter Speed Increment Selector drop-down box and column
const sAdjustContainer =document.querySelector('#adjust-shutter-speed-column');
const sAdjustFull = document.querySelector('#adjust-shutter-speed-full-setting-container');
const sAdjustHalf = document.querySelector('#adjust-shutter-speed-half-setting-container');
const sAdjustThird = document.querySelector('#adjust-shutter-speed-third-setting-container');

// ISO Increment Selector drop-down box and column
const iAdjustContainer =document.querySelector('#adjust-iso-column');
const iAdjustFull = document.querySelector('#adjust-iso-full-settings-container');
const iAdjustHalf = document.querySelector('#adjust-iso-half-setting-container');
const iAdjustThird = document.querySelector('#adjust-iso-third-setting-container');

// Setting drop-downs boxes

// Variables for the F-Stop Setting drop-down boxes
const fFullOption = document.querySelector('#f-stop-full-settings');
const fHalfOption = document.querySelector('#f-stop-half-settings');
const fThirdOption = document.querySelector('#f-stop-third-settings');

// Variables for the Shutter Speed Setting drop-down boxes
const sFullOption = document.querySelector('#shutter-speed-full-settings');
const sHalfOption = document.querySelector('#shutter-speed-half-settings');
const sThirdOption = document.querySelector('#shutter-speed-third-settings');

// Variables for the ISO Setting drop-down boxes
const iFullOption = document.querySelector('#iso-full-settings');
const iHalfOption = document.querySelector('#iso-half-settings');
const iThirdOption = document.querySelector('#iso-third-settings');

// Variable for Text to be displayed below each Setting drop-down box - not currently used
const fSetText = document.querySelector('#f-set');
const sSetText = document.querySelector('#s-set');
const iSetText = document.querySelector('#i-set');

// Adjust drop-downs boxes

// Variables for the F-Stop Adjust drop-down boxes
let fAdjustFullOption = document.querySelector('#adjust-f-stop-full-settings');
let fAdjustHalfOption = document.querySelector('#adjust-f-stop-half-settings');
let fAdjustThirdOption = document.querySelector('#adjust-f-stop-third-settings');

// Variables for the Shutter-Speed Adjust drop-down boxes
let sAdjustFullOption = document.querySelector('#adjust-shutter-speed-full-settings');
let sAdjustHalfOption = document.querySelector('#adjust-shutter-speed-half-settings');
let sAdjustThirdOption = document.querySelector('#adjust-shutter-speed-third-settings');

// Variables for the ISO Adjust drop-down boxes
let iAdjustFullOption = document.querySelector('#adjust-iso-full-settings');
let iAdjustHalfOption = document.querySelector('#adjust-iso-half-settings');
let iAdjustThirdOption = document.querySelector('#adjust-iso-third-settings');

// Variable for the div that displays the Adjust Exposure Value -, +, and 'Value Match'
const adjustedValueContainer = document.querySelector('#adjust-value-container');

// Variable for the adjust exposure button - not used at this point
const adjustBtn = document.querySelector('#adjust-exposure-btn');

// 'Exposure Set' button functionality
setExposure.addEventListener('click', function() {
   
    // Transfers the 'value & text' from the "Settings" drop-down boxes to the cooresponding
    // 'Adjust Settings' drop-down boxes
    fAdjustFullOption.selectedIndex = fFullOption.options[fFullOption.selectedIndex].value;
    fAdjustHalfOption.selectedIndex = fHalfOption.options[fHalfOption.selectedIndex].value;
    fAdjustThirdOption.selectedIndex = fThirdOption.options[fThirdOption.selectedIndex].value;

    sAdjustFullOption.selectedIndex  = sFullOption.options[sFullOption.selectedIndex].value;
    sAdjustHalfOption.selectedIndex  = sHalfOption.options[sHalfOption.selectedIndex].value;
    sAdjustThirdOption.selectedIndex  = sThirdOption.options[sThirdOption.selectedIndex].value;

    iAdjustFullOption.selectedIndex  = iFullOption.options[iFullOption.selectedIndex].value;
    iAdjustHalfOption.selectedIndex  = iHalfOption.options[iHalfOption.selectedIndex].value;
    iAdjustThirdOption.selectedIndex  = iThirdOption.options[iThirdOption.selectedIndex].value;

    // Makes the "Adjust" row divs and button visible
    fAdjustContainer.classList.add('active');
    sAdjustContainer.classList.add('active');
    iAdjustContainer.classList.add('active');
    adjustedValueContainer.classList.add('active');
    adjustBtn.classList.add('active');

    // Logic switch to match the 'Adjust' row drop-down boxes to the same
    // Increments as set in the 'Settings' row
    if(fSelector.value == "Full-Stops")
    {
        fAdjustFull.classList.add('active');
        fAdjustHalf.classList.remove('active');
        fAdjustThird.classList.remove('active');
    }
    if(fSelector.value == "Half-Stops")
    {
        fAdjustFull.classList.remove('active');
        fAdjustHalf.classList.add('active');
        fAdjustThird.classList.remove('active');
     }
    if(fSelector.value == "Third-Stops")
    {
        fAdjustFull.classList.remove('active');
        fAdjustHalf.classList.remove('active');
        fAdjustThird.classList.add('active');
    }
    if(sSelector.value == "Full-Stops")
    {
        sAdjustFull.classList.add('active');
        sAdjustHalf.classList.remove('active');
        sAdjustThird.classList.remove('active');
    }
    if(sSelector.value == "Half-Stops")
    {
        sAdjustFull.classList.remove('active');
        sAdjustHalf.classList.add('active');
        sAdjustThird.classList.remove('active');
    }
    if(sSelector.value == "Third-Stops")
    {
        sAdjustFull.classList.remove('active');
        sAdjustHalf.classList.remove('active');
        sAdjustThird.classList.add('active');
    }
    if(iSelector.value == "Full-Stops")
    {
        iAdjustFull.classList.add('active');
        iAdjustHalf.classList.remove('active');
        iAdjustThird.classList.remove('active');
    }
    if(iSelector.value == "Half-Stops")
    {
        iAdjustFull.classList.remove('active');
        iAdjustHalf.classList.add('active');
        iAdjustThird.classList.remove('active');
    }
    if(iSelector.value == "Third-Stops")
    {
        iAdjustFull.classList.remove('active');
        iAdjustHalf.classList.remove('active');
        iAdjustThird.classList.add('active');
}

// Transfers the values from the 'Settings' to the 'Adjsuted Settings' 
// and calculate the value to for the 'Adjust Value'
// This was add so the 'Adjust' row would start off with an 'Exposure Match'
adjustFStopllEx = currentFStopllEx;
adjustShutterSpeddEx = currentShutterSpeddEx ;
adjustISOEx = currentISOEx;
adjustTotalEx = adjustFStopllEx + adjustShutterSpeddEx + adjustISOEx - currentTotalEx;

// Code to add "+" or "Exposure Match" to "Adjust Value" text
if(adjustTotalEx > 0) {
    adjustValue.innerText = '+' + round(adjustTotalEx, 1) + ' Stops';
} else if (adjustTotalEx == 0){
    adjustValue.innerText = 'Exposure Match';
} else {
    adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';
};
if (adjustTotalEx == 0) {
    adjustValue.classList.add('green');
} else {
    adjustValue.classList.remove('green');
}

// Helpful console.log for testing calculations
// console.log("F-Stop Set is " + currentFStopllEx);
// console.log("Shutter Speed Set is " + currentShutterSpeddEx);
// console.log("ISO Set is " + currentISOEx);
// console.log("Combined Set is " + currentTotalEx);
// console.log("F-Stop Adjust is " + adjustFStopllEx);
// console.log("Shutter Speed Adjust is " + adjustShutterSpeddEx);
// console.log("ISO Adjust is " + adjustISOEx);
// console.log("Combined Adjust is " + adjustTotalEx);
});

// Adjustment Calculator

// Adjust F-Stops

// When the Adjust F-Stop 'Full' drop-down box is visible, event listener calculates
//  the 'Adjusted Exposure'
fAdjustFullOption.addEventListener('change', function() {

    // code to calculate an exposure value from the selected option in the drop-down
    adjustFStopllEx = 0;

    for(i = 1; i <= fAdjustFullOption.options[fAdjustFullOption.selectedIndex].value; i++) {
        
        adjustFStopllEx++;
    }

    // Code to calculate the "Adjust Value" value and  set the text
    adjustTotalEx = 0;
    adjustTotalEx = ((adjustFStopllEx + adjustShutterSpeddEx + adjustISOEx) - currentTotalEx);
    adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';

        // Code to add "+" or "Exposure Match" to "Adjust Value" text
        if(adjustTotalEx > 0) {
            adjustValue.innerText = '+' + round(adjustTotalEx, 1) + ' Stops';
        } else if (adjustTotalEx == 0){
            adjustValue.innerText = 'Exposure Match';
        } else {
            adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';
        };
        if (adjustTotalEx == 0) {
            adjustValue.classList.add('green');
        } else {
            adjustValue.classList.remove('green');
        }
});

// When the AdjustF-Stop 'Full & Half' drop-down box is visible, event listener calculates
//  the 'Adjusted Exposure'
fAdjustHalfOption.addEventListener('change', function() {

    // code to calculate an exposure value from the selected option in the drop-down
    adjustFStopllEx = 0;

    for(i = 0; i <= fAdjustHalfOption.options[fAdjustHalfOption.selectedIndex].value; i++) {
        
        adjustFStopllEx = adjustFStopllEx + .5;
    }

    // Code to calculate the "Adjust Value" value and  set the text
    adjustTotalEx = 0;
    adjustTotalEx = ((adjustFStopllEx + adjustShutterSpeddEx + adjustISOEx) - currentTotalEx);
    adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';

        // Code to add "+" or "Exposure Match" to "Adjust Value" text
        if(adjustTotalEx > 0) {
            adjustValue.innerText = '+' + round(adjustTotalEx, 1) + ' Stops';
        } else if (adjustTotalEx == 0){
            adjustValue.innerText = 'Exposure Match';
        } else {
            adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';
        };
        if (adjustTotalEx == 0) {
            adjustValue.classList.add('green');
        } else {
            adjustValue.classList.remove('green');
        }
});

// When the Adjust F-Stop 'Full & Thirds' drop-down box is visible, event listener calculates
//  the 'Adjusted Exposure'
fAdjustThirdOption.addEventListener('change', function() {

    // code to calculate an exposure value from the selected option in the drop-down
    adjustFStopllEx = .3333333333333;;

    for(i = 0; i <= fAdjustThirdOption.options[fAdjustThirdOption.selectedIndex].value; i++) {
        
        adjustFStopllEx = adjustFStopllEx + 1/3;
        // Code to make whole numbers when 'Thirds' are used
        round(adjustFStopllEx, 1)
        if(adjustFStopllEx > -0.8 && adjustFStopllEx < 0.2){
            adjustFStopllEx = 0;
        }
        if(adjustFStopllEx > 0.8 && adjustFStopllEx < 1.2){
            adjustFStopllEx = 1;
        }
        if(adjustFStopllEx > 1.8 && adjustFStopllEx < 2.2){
            adjustFStopllEx = 2;
        }
        if(adjustFStopllEx > 2.8 && adjustFStopllEx < 3.2){
            adjustFStopllEx = 3;
        }
        if(adjustFStopllEx > 3.8 && adjustFStopllEx < 4.2){
            adjustFStopllEx = 4;
        }
        if(adjustFStopllEx > 4.8 && adjustFStopllEx < 5.2){
            adjustFStopllEx = 5;
        }
        if(adjustFStopllEx > 5.8 && adjustFStopllEx < 6.2){
            adjustFStopllEx = 6;
        }
        if(adjustFStopllEx > 6.8 && adjustFStopllEx < 7.2){
            adjustFStopllEx = 7;
        }
        if(adjustFStopllEx > 7.8 && adjustFStopllEx < 8.2){
            adjustFStopllEx = 8;
        }
        if(adjustFStopllEx > 8.8 && adjustFStopllEx < 9.2){
            adjustFStopllEx = 9;
        }
        if(adjustFStopllEx > 9.8 && adjustFStopllEx < 10.2){
            adjustFStopllEx = 10;
        }
        if(adjustFStopllEx > 10.8 && adjustFStopllEx < 11.2){
            adjustFStopllEx = 11;
        }
    }

    // Code to calculate the "Adjust Value" value and  set the text
    adjustTotalEx = 0;
    adjustTotalEx = ((adjustFStopllEx + adjustShutterSpeddEx + adjustISOEx) - currentTotalEx);
    adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';

        // Code to add "+" or "Exposure Match" to "Adjust Value" text
        if(adjustTotalEx > 0) {
            adjustValue.innerText = '+' + round(adjustTotalEx, 1) + ' Stops';
        } else if (adjustTotalEx == 0){
            adjustValue.innerText = 'Exposure Match';
        } else {
            adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';
        };
        if (adjustTotalEx == 0) {
            adjustValue.classList.add('green');
        } else {
            adjustValue.classList.remove('green');
        }
});

// Adjust Shutter Speed

// When the Adjust Shutter-Speed 'Full' drop-down box is visible, event listener calculates
//  the 'Adjusted Exposure'
sAdjustFullOption.addEventListener('change', function() {

    // code to calculate an exposure value from the selected option in the drop-down
    adjustShutterSpeddEx = 0;

    for(i = 1; i <= sAdjustFullOption.options[sAdjustFullOption.selectedIndex].value; i++) {
        
        adjustShutterSpeddEx++;
    }

    // Code to calculate the "Adjust Value" value and  set the text
    adjustTotalEx = 0;
    adjustTotalEx = ((adjustFStopllEx + adjustShutterSpeddEx + adjustISOEx) - currentTotalEx);
    adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';

        // Code to add "+" or "Exposure Match" to "Adjust Value" text
        if(adjustTotalEx > 0) {
            adjustValue.innerText = '+' + round(adjustTotalEx, 1) + ' Stops';
        } else if (adjustTotalEx == 0){
            adjustValue.innerText = 'Exposure Match';
        } else {
            adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';
        };
        if (adjustTotalEx == 0) {
            adjustValue.classList.add('green');
        } else {
            adjustValue.classList.remove('green');
        }
});

// When the Adjust Shutter-Speed 'Full & Half' drop-down box is visible, event listener calculates
//  the 'Adjusted Exposure'
sAdjustHalfOption.addEventListener('change', function() {

    // code to calculate an exposure value from the selected option in the drop-down
    adjustShutterSpeddEx = 0;

    for(i = 0; i <= sAdjustHalfOption.options[sAdjustHalfOption.selectedIndex].value; i++) {
        
        adjustShutterSpeddEx = adjustShutterSpeddEx + .5;
    }

    // Code to calculate the "Adjust Value" value and  set the text
    adjustTotalEx = 0;
    adjustTotalEx = ((adjustFStopllEx + adjustShutterSpeddEx + adjustISOEx) - currentTotalEx);
    adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';

        // Code to add "+" or "Exposure Match" to "Adjust Value" text
        if(adjustTotalEx > 0) {
            adjustValue.innerText = '+' + round(adjustTotalEx, 1) + ' Stops';
        } else if (adjustTotalEx == 0){
            adjustValue.innerText = 'Exposure Match';
        } else {
            adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';
        };
        if (adjustTotalEx == 0) {
            adjustValue.classList.add('green');
        } else {
            adjustValue.classList.remove('green');
        }
});

// When the Adjust Shutter-Speed 'Full & Thirds' drop-down box is visible, event listener calculates
//  the 'Adjusted Exposure'
sAdjustThirdOption.addEventListener('change', function() {

    // code to calculate an exposure value from the selected option in the drop-down
    adjustShutterSpeddEx = .3333333333333;;

    for(i = 0; i <= sAdjustThirdOption.options[sAdjustThirdOption.selectedIndex].value; i++) {
        
        adjustShutterSpeddEx = adjustShutterSpeddEx + 1/3;
        // Code to make whole numbers when 'Thirds' are used
        round(adjustShutterSpeddEx, 1)
        if(adjustShutterSpeddEx > -0.8 && adjustShutterSpeddEx < 0.2){
            adjustShutterSpeddEx = 0;
        }
        if(adjustShutterSpeddEx > 0.8 && adjustShutterSpeddEx < 1.2){
            adjustShutterSpeddEx = 1;
        }
        if(adjustShutterSpeddEx > 1.8 && adjustShutterSpeddEx < 2.2){
            adjustShutterSpeddEx = 2;
        }
        if(adjustShutterSpeddEx > 2.8 && adjustShutterSpeddEx < 3.2){
            adjustShutterSpeddEx = 3;
        }
        if(adjustShutterSpeddEx > 3.8 && adjustShutterSpeddEx < 4.2){
            adjustShutterSpeddEx = 4;
        }
        if(adjustShutterSpeddEx > 4.8 && adjustShutterSpeddEx < 5.2){
            adjustShutterSpeddEx = 5;
        }
        if(adjustShutterSpeddEx > 5.8 && adjustShutterSpeddEx < 6.2){
            adjustShutterSpeddEx = 6;
        }
        if(adjustShutterSpeddEx > 6.8 && adjustShutterSpeddEx < 7.2){
            adjustShutterSpeddEx = 7;
        }
        if(adjustShutterSpeddEx > 7.8 && adjustShutterSpeddEx < 8.2){
            adjustShutterSpeddEx = 8;
        }
        if(adjustShutterSpeddEx > 8.8 && adjustShutterSpeddEx < 9.2){
            adjustShutterSpeddEx = 9;
        }
        if(adjustShutterSpeddEx > 9.8 && adjustShutterSpeddEx < 10.2){
            adjustShutterSpeddEx = 10;
        }
        if(adjustShutterSpeddEx > 10.8 && adjustShutterSpeddEx < 11.2){
            adjustShutterSpeddEx = 11;
        }
    }

    // Code to calculate the "Adjust Value" value and  set the text
    adjustTotalEx = 0;
    adjustTotalEx = ((adjustFStopllEx + adjustShutterSpeddEx + adjustISOEx) - currentTotalEx);
    adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';

        // Code to add "+" or "Exposure Match" to "Adjust Value" text
        if(adjustTotalEx > 0) {
            adjustValue.innerText = '+' + round(adjustTotalEx, 1) + ' Stops';
        } else if (adjustTotalEx == 0){
            adjustValue.innerText = 'Exposure Match';
        } else {
            adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';
        };
        if (adjustTotalEx == 0) {
            adjustValue.classList.add('green');
        } else {
            adjustValue.classList.remove('green');
        }
});

// Adjust ISO

// When the Adjust ISO 'Full' drop-down box is visible, event listener calculates
//  the 'Adjusted Exposure'
iAdjustFullOption.addEventListener('change', function() {

    // code to calculate an exposure value from the selected option in the drop-down
    adjustISOEx = 0;

    for(i = 1; i <= iAdjustFullOption.options[iAdjustFullOption.selectedIndex].value; i++) {
        
        adjustISOEx++;
    }

    // Code to calculate the "Adjust Value" value and  set the text
    adjustTotalEx = 0;
    adjustTotalEx = ((adjustFStopllEx + adjustShutterSpeddEx + adjustISOEx) - currentTotalEx);
    adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';

        // Code to add "+" or "Exposure Match" to "Adjust Value" text
        if(adjustTotalEx > 0) {
            adjustValue.innerText = '+' + round(adjustTotalEx, 1) + ' Stops';
        } else if (adjustTotalEx == 0){
            adjustValue.innerText = 'Exposure Match';
        } else {
            adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';
        };
        if (adjustTotalEx == 0) {
            adjustValue.classList.add('green');
        } else {
            adjustValue.classList.remove('green');
        }
});

// When the Adjust ISO 'Full & Half' drop-down box is visible, event listener calculates
//  the 'Adjusted Exposure'
iAdjustHalfOption.addEventListener('change', function() {

    // code to calculate an exposure value from the selected option in the drop-down
    adjustISOEx = 0;

    for(i = 0; i <= iAdjustHalfOption.options[iAdjustHalfOption.selectedIndex].value; i++) {
        
        adjustISOEx = adjustISOEx + .5;
    }

    // Code to calculate the "Adjust Value" value and  set the text
    adjustTotalEx = 0;
    adjustTotalEx = ((adjustFStopllEx + adjustShutterSpeddEx + adjustISOEx) - currentTotalEx);
    adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';

        // Code to add "+" or "Exposure Match" to "Adjust Value" text
        if(adjustTotalEx > 0) {
            adjustValue.innerText = '+' + round(adjustTotalEx, 1) + ' Stops';
        } else if (adjustTotalEx == 0){
            adjustValue.innerText = 'Exposure Match';
        } else {
            adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';
        };
        if (adjustTotalEx == 0) {
            adjustValue.classList.add('green');
        } else {
            adjustValue.classList.remove('green');
        }
});

// When the Adjust ISO 'Full & Thirds' drop-down box is visible, event listener calculates
//  the 'Adjusted Exposure'
iAdjustThirdOption.addEventListener('change', function() {

    // code to calculate an exposure value from the selected option in the drop-down
    adjustISOEx = .3333333333333;

    for(i = 0; i <= iAdjustThirdOption.options[iAdjustThirdOption.selectedIndex].value; i++) {
        
        adjustISOEx = adjustISOEx + 1/3;
        // Code to make whole numbers when 'Thirds' are used
        round(adjustISOEx, 1)
        if(adjustISOEx > -0.8 && adjustISOEx < 0.2){
            adjustISOEx = 0;
        }
        if(adjustISOEx > 0.8 && adjustISOEx < 1.2){
            adjustISOEx = 1;
        }
        if(adjustISOEx > 1.8 && adjustISOEx < 2.2){
            adjustISOEx = 2;
        }
        if(adjustISOEx > 2.8 && adjustISOEx < 3.2){
            adjustISOEx = 3;
        }
        if(adjustISOEx > 3.8 && adjustISOEx < 4.2){
            adjustISOEx = 4;
        }
        if(adjustISOEx > 4.8 && adjustISOEx < 5.2){
            adjustISOEx = 5;
        }
        if(adjustISOEx > 5.8 && adjustISOEx < 6.2){
            adjustISOEx = 6;
        }
        if(adjustISOEx > 6.8 && adjustISOEx < 7.2){
            adjustISOEx = 7;
        }
        if(adjustISOEx > 7.8 && adjustISOEx < 8.2){
            adjustISOEx = 8;
        }
        if(adjustISOEx > 8.8 && adjustISOEx < 9.2){
            adjustISOEx = 9;
        }
        if(adjustISOEx > 9.8 && adjustISOEx < 10.2){
            adjustISOEx = 10;
        }
        if(adjustISOEx > 10.8 && adjustISOEx < 11.2){
            adjustISOEx = 11;
        }
    }

    // Code to calculate the "Adjust Value" value and  set the text
    adjustTotalEx = 0;
    adjustTotalEx = ((adjustFStopllEx + adjustShutterSpeddEx + adjustISOEx) - currentTotalEx);
    adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';

    // Code to add "+" or "Exposure Match" to "Adjust Value" text
    if(adjustTotalEx > 0) {
        adjustValue.innerText = '+' + round(adjustTotalEx, 1) + ' Stops';
    } else if (adjustTotalEx == 0){
        adjustValue.innerText = 'Exposure Match';
    } else {
        adjustValue.innerText = round(adjustTotalEx, 1) + ' Stops';
    };
    if (adjustTotalEx == 0) {
        adjustValue.classList.add('green');
    } else {
        adjustValue.classList.remove('green');
    }
});

// Below is a useful console.log setup tp diagnose the 'Baseline' and 'Adjusted' values
// console.log("F-Stop Set is " + currentFStopllEx);
// console.log("Shutter Speed Set is " + currentShutterSpeddEx);
// console.log("ISO Set is " + currentISOEx);
// console.log("Combined Set is " + currentTotalEx);
// console.log("F-Stop Adjust is " + adjustFStopllEx);
// console.log("Shutter Speed Adjust is " + adjustShutterSpeddEx);
// console.log("ISO Adjust is " + adjustISOEx);
// console.log("Combined Adjust is " + adjustTotalEx);