// JavaScript Quote Generator
// 
// Variables
// 
// document.querySelector() Returns the first element in the document that matches selector
// in the parenthesis. Notice that, like in CSS, you need to use # when selecting IDs and
// the . notation when selecting classes.

// Line 12 creates a variable 'btn' which contains 
// the html button with the 'id' of '#new-quote'

let btn = document.querySelector('#new-quote');

// Line 16 creates a variable 'quote' which contains 'class' of '.quote'

let quote = document.querySelector('.quote');

// Line 20 creates a variable 'person' which contains 'class' of '.person'

let person = document.querySelector('.person');

// Lines 40 thru 129 create a variable 'quotes' which is an array that contains 20 'objects'.
// Each 'object' has its own set of curly brackets and contain name:value pairs. A comma
// used to separate the 'objects.
// {
//      quote: 'value'
//      person: 'value'
// },
// The names in these objects are the same as the variables created on lines 16 'quote'
// and 20 'person', this allows us to use those variables to change the elements on the 
// html page with the classes contained in those variables. On the html page there is only
// one object that has the '.quote' class and only one that has the '.person' class.
// This 'quotes' array allows us to keep each 'quote' and 'person' paired within the 
// same object, thus we can use one array 'index' [number] to recall both variables.
// We generate a random number 'random', and use random in indexing for both 'quote' 
// and 'person': 'quotes[random].quote' and 'quotes[random].person'. This assures us
// that our code will return the right author with their quote. Scroll down passed the
// 'quotes' array for the rest of the code.

const quotes = [
    {
        quote:'"The greatest glory in living lies not in never falling, but in rising every time we fall."',
        person: 'Nelson Mandela'
    },
    {
        quote:'"The way to get started is to quit talking and begin doing."',
        person: 'Walt Disney'
    },
    {
        quote:'"Your time is limited, so don\'t waste it living someone else\'s life. Don\'t be trapped by dogma - which is living with the results of other people\'s thinking."',
        person: 'Steve Jobs'
    },
    {
        quote:'"If life were predictable it would cease to be life, and be without flavor."',
        person: 'Eleanor Roosevelt'
    },
    {
        quote:'"If you look at what you have in life, you\'ll always have more. If you look at what you don\'t have in life, you\'ll never have enough."',
        person: 'Oprah Winfrey'
    },
    {
        quote:'"If you set your goals ridiculously high and it\'s a failure, you will fail above everyone else\'s success."',
        person: 'James Cameron'
    },
    {
        quote:'"Life is what happens when you\'re busy making other plans."',
        person: 'John Lennon'
    },
    {
        quote:'"Spread love everywhere you go. Let no one ever come to you without leaving happier."',
        person: 'Mother Teresa'
    },
    {
        quote:'"When you reach the end of your rope, tie a knot in it and hang on."',
        person: 'Franklin D. Roosevelt'
    },
    {
        quote:'"Always remember that you are absolutely unique. Just like everyone else."',
        person: 'Margaret Mead'
    },
    {
        quote:'"Don\'t judge each day by the harvest you reap but by the seeds that you plant."',
        person: 'Robert Louis Stevenson'
    },
    {
        quote:'"The future belongs to those who believe in the beauty of their dreams."',
        person: 'Eleanor Roosevelt'
    },
    {
        quote:'"Tell me and I forget. Teach me and I remember. Involve me and I learn."',
        person: 'Benjamin Franklin'
    },
    {
        quote:'"The best and most beautiful things in the world cannot be seen or even touched — they must be felt with the heart."',
        person: 'Helen Keller'
    },
    {
        quote:'"It is during our darkest moments that we must focus to see the light."',
        person: 'Aristotle'
    },
    {
        quote:'"Whoever is happy will make others happy too"',
        person: 'Anne Frank'
    },
    {
        quote:'"Do not go where the path may lead, go instead where there is no path and leave a trail."',
        person: 'Ralph Waldo Emerson'
    },
    {
        quote:'"You will face many defeats in life, but never let yourself be defeated."',
        person: 'Maya Angelou'
    },
    {
        quote:'"In the end, it\'s not the years in your life that count. It\'s the life in your years."',
        person: 'Abraham Lincoln'
    },
    {
        quote:'"Never let the fear of striking out keep you from playing the game."',
        person: 'Babe Ruth'
    },
    {
        quote:'"Many of life\'s failures are people who did not realize how close they were to success when they gave up"',
        person: 'Thomas A. Edison'
    },
    {
        quote:'"You have brains in your head. You have feet in your shoes. You can steer yourself any direction you choose."',
        person: 'Dr. Seuss'
    }
]

// Lines 164 to 171 adds the 'EventListener', sets it to listen for a 'click', when a 'click'
// is heard it runs the 'function'. On line 168, the function creates a variable 'random'
// and assign it a value that will generate a random number each time it is called.
// Math.floor() will round down any number passed into the parenthesis, for example,
// Math.floor(1.9) would return 1. Try it by un-commenting out line 137 and save the change

// console.log(Math.floor(1.9));

// Math.random() generates a random number for 0 to 1, with 0 included, but 1 is excluded.
// Math.random() will never return the number 1. Try it by un-commenting out line 144 and 
// save the change. Each time you save, Math.random() will generate a new random number.
// Math.random() can return 0 thru 0.9999999999999999, but never 1

// console.log(Math.random());

// Comment out lines 137 and 144
// In creating the 'random' variable we are multiplying the result of 'Math.random()' 
// by 'quotes.length' and using Math.floor() to round down the result, this will be the
// number we used to identify and replace the author and quote on the web page.
// 'Math.floor(Math.random() * quotes.length)' works because an array 'index' starts with 0.
// An array of 20 items has an index of 0 thru 19, the 20th item is 'index' 19.
// Math.random() can return 0 thru 0.9999999999999999
// 0.9999999999999999 * quotes.length = 19.999999999999998
// 19.999999999999998 is the highest number that can be generated in this function
// That mean when we pass the result through Math.floor(), the highest number
// that can be returned is 19, so 'Math.floor(Math.random() * quotes.length)' can return
// whole numbers 0 thru 19, and our array is indexed 0 thru 19
// In our function, once the 'random' variable is created line 168 is uses it to re-assign the
// '.innerText' value of the variable 'quote' to the 'quote' in the object at the 'index'
// that matches the 'random' number. The same 'random' number is used on line 169 to 
// re-assign the'.innerText' value of the variable 'person' to the 'person' in the object 
// at the 'index' that matches the 'random' number. 

btn.addEventListener('click', function() {

    let random = Math.floor(Math.random() * quotes.length);

    quote.innerText = quotes[random].quote;
    person.innerText = quotes[random].person;

})

// Everytime you 'click; the 'New Quote' button you should get a new quote.
// Try it out.